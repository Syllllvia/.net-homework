﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace homework_2._4
{
    delegate void AlarmHandler(object sender, Time args);
    delegate void TickHandler(object sender);

    class Time
    {
        public Time(int hour, int minute, int second)
        {
            if (hour >= 0 && hour <= 24) this.hour = hour;
            if (minute >= 0 && minute <= 60) this.minute = minute;
            if (second >= 0 && second <= 60) this.second = second;
        }

        public bool Equals(Time newTime)                             // 判断时间是否相同
        {
            if (newTime.hour == this.hour && newTime.minute == this.minute && newTime.second == this.second) return true;
            else return false;
        }

        public int hour;
        public int minute;
        public int second;
    }

    class AlarmController
    {
        public event AlarmHandler AlarmEvent;                        // Alarm事件
        public Time alarmTime;

        public void SetAlarmTime(int hour, int minute, int second)   // 闹铃时间
        {
            alarmTime = new Time(hour, minute, second);
        }

        public void Alarm()
        {
            AlarmEvent(this, alarmTime);                             // 触发Alarm事件
        }
    }

    class Clock
    {
        public AlarmController alarm = new AlarmController();
        public event TickHandler TickEvent;                          // Tick事件
        public Time nowTime = new Time(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

        public void FreshTime()                                      // 更新时间
        {
            nowTime.hour = DateTime.Now.Hour;
            nowTime.minute = DateTime.Now.Minute;
            nowTime.second = DateTime.Now.Second;
        }

        public void ShowNowTime()                                    // 显示当前时间
        {
            Console.Write(nowTime.hour.ToString().PadLeft(2, '0') + ":");
            Console.Write(nowTime.minute.ToString().PadLeft(2, '0') + ":");
            Console.Write(nowTime.second.ToString().PadLeft(2, '0') + "\n");
        }

        public void Tick()
        {
            TickEvent(this);
        }

        public Clock()
        {
            TickEvent += ClockTick;
            alarm.AlarmEvent += Alarm;
        }

        public void Start()
        {
            while (!nowTime.Equals(alarm.alarmTime))
            {
                FreshTime();
                Tick();
                Thread.Sleep(1000);  // 挂起一秒
            }

            alarm.Alarm();
        }

        void ClockTick(object sender)
        {
            Console.WriteLine("Tick......");
            Console.WriteLine("Now time is: ");
            ShowNowTime();
            Console.WriteLine("");
        }

        void Alarm(object sender, Time alarmTime)
        {
            Console.WriteLine("DingLing Ling Ling!");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Clock clock = new Clock();
                int hour, minute, second;
                Console.WriteLine("Set clock：");
                hour = int.Parse(Console.ReadLine());
                minute = int.Parse(Console.ReadLine());
                second = int.Parse(Console.ReadLine());

                clock.alarm.SetAlarmTime(hour, minute, second);
                clock.Start();
            }
            catch
            {
                Console.WriteLine("您的输入有误！");
            }
            Console.ReadLine();
        }
    }
}

