﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Factory factory = new Factory();
            List<Shape> shapeList = new List<Shape>();

            for (int i = 0; i < 10; i++)
            {
                shapeList.Add(factory.GetRandomShape());
            }
            
            double sum = 0;
            shapeList.ForEach(s => sum += s.S);
            Console.WriteLine("The total area is: " + sum);
            Console.ReadLine();
        }
    }
}
