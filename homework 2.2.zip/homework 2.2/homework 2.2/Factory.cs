﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework_2._2
{
    enum ShapeType
    {
        Rectangle,
        Circle,
        Triangle,
    }

    abstract class Shape
    {
        private float s;
        public float S
        {
            get
            {
                return s;
            }
            set
            {
                if (value >= 0)
                { s = value; }
            }
        }
    }
    class Rectangle : Shape
    {
        public float GetArea(float c, float k)
        {
            return S = c * k;
        }
    }
    class Circle : Shape
    {
        static double PI = 3.1415926;
        public float GetArea(float r)
        {
            return S = Convert.ToSingle(PI * r * r);
        }
    }

    class Triangle : Shape
    {
        public float GetArea(float a, float b, float c)
        {
            float HalfLength = (a + b + c) / 2;
            return S = Convert.ToSingle(Math.Sqrt(HalfLength * (HalfLength - a) * (HalfLength - b) * (HalfLength - c)));
        }
    }

    class Factory
    {
        private Random random = new Random();           // 在循环外随机生成所需的图形

        public Shape GetShape(ShapeType shapeType)
        {
            switch (shapeType)
            {
                case ShapeType.Rectangle:
                    return new Rectangle();
                case ShapeType.Circle:
                    return new Circle();
                case ShapeType.Triangle:
                    return new Triangle();
                default:
                    throw new InvalidOperationException("Invalid shape type:" + shapeType);
            }
        }

        public Shape GetRandomShape()
        {
            ShapeType[] shapeTypes = Enum.GetValues(typeof(ShapeType)) as ShapeType[];
            ShapeType shapeType = shapeTypes[random.Next(0, shapeTypes.Length)];
            switch (shapeType)
            {
                case ShapeType.Rectangle:
                    return new Rectangle();
                case ShapeType.Circle:
                    return new Circle();
                case ShapeType.Triangle:
                    return new Triangle();
                default:
                    return null;
            }
        }
    }
}
